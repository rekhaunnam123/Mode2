import { Component } from '@angular/core';
import { Employee } from './Employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular';
  favouriteMovie:string="Lord of the Rings";
  emp:Employee={
    id:10,
    name:"john",
    salary:200000,
    permanent:"Yes",
    department:{dept_id:1,dept_name:"payroll"},
    skill:[
    {skill_id:100,skill_name:"java"},
    {skill_id:101,skill_name:"c++"},
    {skill_id:102,skill_name:"oracle"}],
    dob:new Date('12/31/2000')
  };
}



 