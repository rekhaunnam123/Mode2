import { Department } from './Department';
import { Skill } from './Skill';

export interface Employee
{
    id:number;
    name:string;
    salary:number;
    permanent:string
    department:Department;
    skill:Skill[];
    dob:Date;
}
